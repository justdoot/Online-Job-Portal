package com.app.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.recruiter.entities.Recruiter;

public interface RecruiterDao extends JpaRepository<Recruiter,Long> {

}
