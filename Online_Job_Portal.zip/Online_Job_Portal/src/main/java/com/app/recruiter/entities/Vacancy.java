package com.app.recruiter.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "vacancy")
@NoArgsConstructor
@Getter
@Setter
@ToString

public class Vacancy extends BaseEntity{
	
	@Column
	private long salary;
	
	@Column(length=30)
	private String title;
	
	@Column(length=100)
	private String description;
	
	@Column(length=30)
	private String location;
	
	@OneToOne
	@JoinColumn(name="js_id")
	@MapsId
	private RecruiterRequirements requirements;
	
	@ManyToOne
	@JoinColumn(name="rec_id")
	@MapsId
	private Recruiter owner;

}
