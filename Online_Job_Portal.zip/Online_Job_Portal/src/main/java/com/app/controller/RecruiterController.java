package com.app.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.RecruiterDTO;
import com.app.dto.RecruiterDetailsDTO;
import com.app.dto.VacancyDTO;
import com.app.service.RecruiterService;

@RestController
@RequestMapping("/rec")
public class RecruiterController {
	
	@Autowired
	private RecruiterService recService;
	
	@GetMapping("/{rec_id}")
	public ResponseEntity<?> getRecruiter(@PathVariable Long rec_id) throws Exception
	{
		return ResponseEntity.ok(recService.getRec(rec_id));
	}
	
	@GetMapping("/details/{rec_id}")
	public ResponseEntity<?> getRecruiterDetails(@PathVariable Long rec_id) throws Exception
	{
		return ResponseEntity.ok(recService.getRecDetails(rec_id));
	}
	
	@PostMapping
	public ResponseEntity<?> addRecruiteer(@RequestBody @Valid RecruiterDTO dto) throws Exception
	{
		return ResponseEntity.status(HttpStatus.CREATED).body(recService.addNewRec(dto));
		
	}
	
	@PutMapping("/{rec_id}")
	public ResponseEntity<?> updateRecruiter(@PathVariable Long rec_id,@RequestBody @Valid RecruiterDTO dto) throws Exception
	{
		return ResponseEntity.ok(recService.updateRec(rec_id,dto));
	}
	
	@PutMapping("/details/{rec_id}")
	public ResponseEntity<?> updateRecruiterDetails(@PathVariable Long rec_id,@RequestBody @Valid RecruiterDetailsDTO dto) throws Exception
	{
		return ResponseEntity.ok(recService.updateRecDetails(rec_id,dto));
	}
	
	@GetMapping("/{rec_id}/vac")
	public ResponseEntity<?> getAllVacancies(@PathVariable Long rec_id) throws Exception
	{
		return ResponseEntity.ok(recService.getAllVacancies(rec_id));
		
	}
	@PostMapping("{rec_id}/vac")
	public ResponseEntity<?> addVacancy(@PathVariable Long rec_id, @RequestBody @Valid VacancyDTO dto) throws Exception
	{
		return ResponseEntity.status(HttpStatus.CREATED).body(recService.addNewVac(dto));
		
	}

}
