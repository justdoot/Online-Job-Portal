package com.app.dto;

import java.time.LocalDate;

import javax.persistence.Column;

import com.app.seeker.entities.Address;
import com.app.seeker.entities.SeekerSkills;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class SeekerDetailsDTO {
	
	
	private String fName;
	
	
	private String lName;
	
	
	private LocalDate dob;
	

	private String college;
	

	private String degree;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private String street;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private String city;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private String state;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private String country;

	@JsonProperty(access = Access.WRITE_ONLY)
	private String zipCode;
	
	@JsonProperty(access = Access.READ_ONLY)
	private Address adr;
	
	@JsonProperty(access = Access.READ_ONLY)
	private SeekerSkills skills;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private boolean cpp;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private boolean java;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private boolean dotNet;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private boolean nodeJS;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private boolean reactJS;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private boolean spring;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private boolean database;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private boolean linux;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private boolean devopsTech;
	
	
	

}
