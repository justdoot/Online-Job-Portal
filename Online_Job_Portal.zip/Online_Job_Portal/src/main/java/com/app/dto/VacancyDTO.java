package com.app.dto;

import com.app.recruiter.entities.RecruiterRequirements;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@ToString
public class VacancyDTO {
	
	private long salary;
	

	private String title;
	

	private String desc;
	

	private String location;
	
	
	private RecruiterRequirements requirements;

}
