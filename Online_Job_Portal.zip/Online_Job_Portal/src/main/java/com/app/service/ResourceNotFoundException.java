package com.app.service;

public class ResourceNotFoundException extends Exception{
	
	ResourceNotFoundException(String msg)
	{
		super(msg);
	}

}
