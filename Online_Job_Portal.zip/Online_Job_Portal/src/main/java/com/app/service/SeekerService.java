package com.app.service;

import com.app.dto.SeekerDTO;

public interface SeekerService {
	
	SeekerDTO addNewSeeker(SeekerDTO dto);
	
	SeekerDTO updateSeeker(Long js_id,SeekerDTO dto);
	
	SeekerDTO getSeeker(Long js_id) throws Exception;

}
