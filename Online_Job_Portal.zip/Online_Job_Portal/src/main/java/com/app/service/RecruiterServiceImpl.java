package com.app.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dao.RecruiterDao;
import com.app.dao.RecruiterDetailsDao;
import com.app.dao.RecruiterRequirementsDao;
import com.app.dao.VacancyDao;
import com.app.dto.AuthReqDTO;
import com.app.dto.RecruiterDTO;
import com.app.dto.RecruiterDetailsDTO;
import com.app.recruiter.entities.Address;
import com.app.recruiter.entities.Recruiter;
import com.app.recruiter.entities.RecruiterDetails;

@Service
@Transactional

public class RecruiterServiceImpl implements RecruiterService {
	
	@Autowired
	private RecruiterDao recRepo;
	
	@Autowired 
	private RecruiterDetailsDao recDetRepo;
	
	@Autowired
	private VacancyDao vacRepo;
	
	@Autowired 
	private RecruiterRequirementsDao recReqRepo;
	
	@Autowired
	private ModelMapper mapper;

	@Override
	public RecruiterDTO addNewRec(RecruiterDTO dto) throws Exception {
		if(dto.getPassword().equals(dto.getConfirmPassword()))
		{
			Recruiter rec = mapper.map(dto,Recruiter.class);
			RecruiterDetails recDet = new RecruiterDetails();
			rec.setDetails(recDet);
			recRepo.save(rec);
			recDetRepo.save(recDet);
			return mapper.map(rec, RecruiterDTO.class);
			
			
		}
		return null;
		
	}

	@Override
	public RecruiterDTO updateRec(Long rec_id, RecruiterDTO dto) throws Exception {
		if(dto.getPassword().equals(dto.getConfirmPassword()))
		{
			Recruiter rec = recRepo.findById(rec_id).orElseThrow(()-> new ResourceNotFoundException("Invalid Id"));
			Recruiter updatedRec = mapper.map(dto,Recruiter.class);
			rec.setEmail(updatedRec.getEmail());
			rec.setPassword(updatedRec.getPassword());
			rec.setPh_no(updatedRec.getPh_no());
			
			updatedRec = recRepo.save(rec);
			return mapper.map(updatedRec, RecruiterDTO.class);
			
		}
		return null;
	}

	@Override
	public RecruiterDTO getRec(Long rec_id) throws Exception {
		Recruiter rec = recRepo.findById(rec_id).orElseThrow(()-> new ResourceNotFoundException("Invalid Id"));
		return mapper.map(rec,  RecruiterDTO.class);
	}

	@Override
	public RecruiterDetailsDTO getRecDetails(Long rec_id) throws Exception {
       RecruiterDetails rec = recDetRepo.findById(rec_id).orElseThrow(()-> new ResourceNotFoundException("Invalid Id"));
		
		return mapper.map(rec, RecruiterDetailsDTO.class);
	}

	@Override
	public RecruiterDetailsDTO updateRecDetails(Long rec_id, RecruiterDetailsDTO dto) throws Exception {
		RecruiterDetails rec = recDetRepo.findById(rec_id).orElseThrow(()-> new ResourceNotFoundException("Invalid Id"));
		dto.setAdr(new Address(dto.getStreet(), dto.getCity(), dto.getState(), dto.getCountry(), dto.getZipCode()));
		RecruiterDetails updatedRec = mapper.map(dto, RecruiterDetails.class);
		rec.setAdr(updatedRec.getAdr());
		rec.setCompany_size(updatedRec.getCompany_size());
		rec.setCompanyName(updatedRec.getCompanyName());
		rec.setDescription(updatedRec.getDescription());
		rec.setIndustry(updatedRec.getIndustry());
		rec.setWebsite(updatedRec.getWebsite());
		updatedRec = recDetRepo.save(rec);
		return mapper.map(updatedRec,RecruiterDetailsDTO.class);
	}

	@Override
	public RecruiterDetailsDTO authenticateRec(AuthReqDTO req) throws Exception {
		Recruiter rec = recRepo.findByEmailAndPassword(req.getEmail(),req.getPassword()).orElseThrow(()-> new ResourceNotFoundException("Invalid credentials"));
		
		RecruiterDetails recDet = recDetRepo.findById(rec.getRec_id()).orElseThrow(()-> new ResourceNotFoundException("Id not valid"));
		
		return mapper.map(recDet,RecruiterDetailsDTO.class);
	}

}
