package com.app.service;

import com.app.dto.AuthReqDTO;
import com.app.dto.RecruiterDTO;
import com.app.dto.RecruiterDetailsDTO;
import com.app.dto.SeekerDetailsDTO;

public interface RecruiterService {
	
	RecruiterDTO addNewRec(RecruiterDTO dto) throws Exception;
	
	RecruiterDTO updateRec(Long rec_id,RecruiterDTO dto) throws Exception;
	
	RecruiterDTO getRec(Long rec_id) throws Exception;
	
	RecruiterDetailsDTO getRecDetails(Long rec_id) throws Exception;
	
	RecruiterDetailsDTO updateRecDetails(Long rec_id, RecruiterDetailsDTO dto) throws Exception;
	
	RecruiterDetailsDTO authenticateRec(AuthReqDTO req) throws Exception;
	

}
