package com.app.service;


import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.AddressDao;
import com.app.dao.SeekerDao;
import com.app.dao.SeekerDetailsDao;
import com.app.dto.SeekerDTO;
import com.app.entities.Seeker;

@Service 
@Transactional

public class SeekerServiceImpl implements SeekerService {
	
	@Autowired
	private SeekerDao seekerRepo;
	
	@Autowired 
	private AddressDao adrRepo;
	
	@Autowired
	private SeekerDetailsDao seekDetRepo;
	
	@Autowired
	private ModelMapper mapper;

	@Override
	public SeekerDTO addNewSeeker(SeekerDTO dto) {
		if(dto.getPassword().equals(dto.getConfirmPassword()))
		{
			Seeker seekerEntity = mapper.map(dto, Seeker.class);
			Seeker savedSeeker = seekerRepo.save(seekerEntity);
			return mapper.map(savedSeeker, SeekerDTO.class);
		}
		return null;
		//throw new ApiException("Passwords don't match");
	}

	@Override
	public SeekerDTO updateSeeker(Long js_id, SeekerDTO dto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SeekerDTO getSeeker(Long js_id) throws ResourceNotFoundException {
		
		Seeker seeker = seekerRepo.findById(js_id).orElseThrow(()-> new ResourceNotFoundException("Invalid Id"));
		
		return mapper.map(seeker, SeekerDTO.class);
	}
	
	


}
