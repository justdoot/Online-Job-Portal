package com.app.seeker.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="seeker_skills")
@NoArgsConstructor
@Getter
@Setter
@ToString

public class SeekerSkills extends BaseEntity {
	
	@Column
	private boolean cpp;
	
	@Column
	private boolean java;

	@Column
	private boolean dotNet;
	
	@Column
	private boolean nodeJS;
	
	@Column
	private boolean reactJS;
	
	@Column
	private boolean spring;
	
	@Column
	private boolean databse;
	
	@Column
	private boolean linux;
	
	@Column
	private boolean devopsTech;
	
	
	public SeekerSkills(boolean cpp,boolean java,boolean dotnet, boolean node, boolean react, boolean spring, boolean linux, boolean devops,boolean database)
	{
		this.cpp = cpp;
		this.java = java;
		this.dotNet = dotnet;
		this.nodeJS = node;
		this.reactJS = react;
		this.spring = spring;
		this.linux = linux;
		this.devopsTech = devops;
		this.databse = database;
	}
	
}
