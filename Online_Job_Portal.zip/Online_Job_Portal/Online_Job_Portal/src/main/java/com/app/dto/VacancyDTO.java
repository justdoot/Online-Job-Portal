package com.app.dto;



import com.app.recruiter.entities.VacancyRequirements;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
@Getter
@Setter
@ToString
public class VacancyDTO {
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private long rec_id;
	
	private long salary;
	

	private String title;
	

	private String desc;
	

	private String location;
	
	@JsonProperty(access=Access.READ_ONLY)
	private VacancyRequirements requirements;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private String education;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private boolean cpp;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private boolean java;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private boolean dotNet;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private boolean nodeJS;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private boolean reactJS;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private boolean spring;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private boolean database;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private boolean linux;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	private boolean devopsTech;

}
