import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <div className="container my-5">
      <div className="container-fluid p-4 pb-0">
        <footer>
          <div className="row">
            <div className="col-lg-4 col-md-6 mb-4 mb-md-0">
              <h5 className="text-uppercase text-color-second">
                Online Job Portal
              </h5>
              <p>
                Welcome to our Online Job Portal, where career dreams come to
                life. Our user-friendly platform simplifies job searching,
                offering a seamless experience for both job seekers and
                employers.
              </p>
            </div>
          </div>
        </footer>
        <hr className="mb-4" />
      </div>
      <div className="text-center">
        © 2023 Copyright:
        <a className="text-color-3">Your Company Name</a>
      </div>
    </div>
  );
};

export default Footer;
