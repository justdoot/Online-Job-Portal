package com.jobportal.service;

import com.jobportal.entity.Address;

public interface AddressService {
	
	Address addUserAddress(Address address);

}
