package com.app.seeker.entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.app.recruiter.entities.Vacancy;
import com.app.roles.entities.Role;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "seeker")
@NoArgsConstructor
@Getter
@Setter
@ToString

public class Seeker extends BaseEntity {
	
	@Column(length=30,unique=true,nullable=false)
	private String email;
	@Column(nullable=false)
	private String password;
	@Column(length=10)
	private long ph_no;
	
	
	@OneToOne
	@JoinColumn(name="js_id")
	@MapsId
	private SeekerDetails details;
	
	@ManyToMany
	@JoinColumn(name="js_id")
	private List<Vacancy> vacancies;
	
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinTable(name="seeker_roles", joinColumns = @JoinColumn(name="js_id", referencedColumnName="js_id",nullable=true),
	inverseJoinColumns = @JoinColumn(name="role_id",referencedColumnName="role_id",nullable=true))
	private Role role;
	

	
	
	

}
