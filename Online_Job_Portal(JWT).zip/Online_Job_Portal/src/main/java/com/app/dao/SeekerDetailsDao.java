
package com.app.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.seeker.entities.SeekerDetails;

public interface SeekerDetailsDao extends JpaRepository<SeekerDetails,Long>{

}
