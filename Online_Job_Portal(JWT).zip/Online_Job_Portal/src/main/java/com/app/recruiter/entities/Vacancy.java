package com.app.recruiter.entities;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.app.seeker.entities.Seeker;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "vacancy")
@NoArgsConstructor
@Getter
@Setter
@ToString

public class Vacancy {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="vac_id")
	private long vac_id;
	
	@Column
	private long salary;
	
	@Column(length=30)
	private String title;
	
	@Column(length=100)
	private String description;
	
	@Column(length=30)
	private String location;
	
	@OneToOne
	@JoinColumn(name="vac_id")
	@MapsId
	private VacancyRequirements requirements;
	
	@ManyToOne
	@JoinColumn(name="rec_id")
	private Recruiter owner;
	
	@ManyToMany
	@JoinColumn(name="js_id")
	private List<Seeker> seekers; 
}
