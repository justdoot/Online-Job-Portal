package com.app.recruiter.entities;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.app.seeker.entities.Address;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="rec_details")
@NoArgsConstructor
@Getter
@Setter
@ToString

public class RecruiterDetails extends BaseEntity{
	
	@Column(length=30)
	private String companyName;
	
	@Column(length=30)
	private String website;
	
	@Column(length=30)
	private String industry;
	
	@Column
	private long company_size;
	
	@Column(length=100)
	private String description;
	
	
	@Embedded
	private Address adr;
	

}
