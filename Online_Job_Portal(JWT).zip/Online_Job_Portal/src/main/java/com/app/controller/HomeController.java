package com.app.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.AuthReqDTO;
import com.app.dto.AuthRespDTO;
import com.app.dto.RecruiterDTO;
import com.app.dto.SeekerDTO;
import com.app.security_config.JwtGenerator;
import com.app.service.RecruiterService;
import com.app.service.SeekerService;

@RestController
@RequestMapping("/home")
public class HomeController {
	
	@Autowired
	private SeekerService seekerServ;
	
	@Autowired
	private RecruiterService recServ;
	
	@Autowired
	private AuthenticationManager authMan;
	
	@Autowired
	private PasswordEncoder passEncoder;
	
	@Autowired
	private JwtGenerator jwtGenerator;
	
	
	@PostMapping("/login")
	
	public ResponseEntity<?> authenticateEmp(@RequestBody @Valid AuthReqDTO req)
	{
		
		Authentication authentication = authMan.authenticate(
				new UsernamePasswordAuthenticationToken(req.getEmail(),req.getPassword()));
		SecurityContextHolder.getContext().setAuthentication(authentication);
		String token = jwtGenerator.generateToken(authentication);
		return ResponseEntity.status(HttpStatus.ACCEPTED).body(new AuthRespDTO(token));
		
	}
	
	@PostMapping("/register/seeker")
	public ResponseEntity<?> addSeeker(@RequestBody @Valid SeekerDTO dto) throws Exception
	{
		if(dto.getPassword().equals(dto.getConfirmPassword()))
		{
			dto.setPassword(passEncoder.encode(dto.getPassword()));
		return ResponseEntity.status(HttpStatus.CREATED).body(seekerServ.addNewSeeker(dto));
		}
		
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
		
	}
	@PostMapping("/register/rec")
	public ResponseEntity<?> addRecruiter(@RequestBody @Valid RecruiterDTO dto) throws Exception
	{
		if(dto.getPassword().equals(dto.getConfirmPassword()))
		{
			dto.setPassword(passEncoder.encode(dto.getPassword()));
		 return ResponseEntity.status(HttpStatus.CREATED).body(recServ.addNewRec(dto));
		}
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
		
		
		
	}
	

}
