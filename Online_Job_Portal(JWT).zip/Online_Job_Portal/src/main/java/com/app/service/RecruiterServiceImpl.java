package com.app.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dao.RecruiterDao;
import com.app.dao.RecruiterDetailsDao;
import com.app.dao.RecruiterRequirementsDao;
import com.app.dao.RoleDao;
import com.app.dao.VacancyDao;
import com.app.dto.AuthReqDTO;
import com.app.dto.RecruiterDTO;
import com.app.dto.RecruiterDetailsDTO;
import com.app.dto.SeekerDTO;
import com.app.dto.VacancyDTO;
import com.app.recruiter.entities.Address;
import com.app.recruiter.entities.Recruiter;
import com.app.recruiter.entities.RecruiterDetails;
import com.app.recruiter.entities.Vacancy;
import com.app.recruiter.entities.VacancyRequirements;
import com.app.roles.entities.Role;
import com.app.seeker.entities.Seeker;

@Service
@Transactional

public class RecruiterServiceImpl implements RecruiterService{
	
	@Autowired
	private RecruiterDao recRepo;
	
	@Autowired 
	private RecruiterDetailsDao recDetRepo;
	
	@Autowired
	private VacancyDao vacRepo;
	
	@Autowired 
	private RecruiterRequirementsDao recReqRepo;
	
	@Autowired
	private ModelMapper mapper;
	
	@Autowired
	private RoleDao roleRepo;

	@Override
	public RecruiterDTO addNewRec(RecruiterDTO dto) throws Exception {
		
			Recruiter rec = mapper.map(dto,Recruiter.class);
			RecruiterDetails recDet = new RecruiterDetails();
			rec.setDetails(recDet);
			rec.setRole(roleRepo.findByName("rec").get());
			recRepo.save(rec);
			recDetRepo.save(recDet);
			return mapper.map(rec, RecruiterDTO.class);
		
	}

	@Override
	public RecruiterDTO updateRec(Long rec_id, RecruiterDTO dto) throws Exception {
		if(dto.getPassword().equals(dto.getConfirmPassword()))
		{
			Recruiter rec = recRepo.findById(rec_id).orElseThrow(()-> new ResourceNotFoundException("Invalid Id"));
			Recruiter updatedRec = mapper.map(dto,Recruiter.class);
			rec.setEmail(updatedRec.getEmail());
			rec.setPassword(updatedRec.getPassword());
			rec.setPh_no(updatedRec.getPh_no());
			
			updatedRec = recRepo.save(rec);
			return mapper.map(updatedRec, RecruiterDTO.class);
			
		}
		return null;
	}

	@Override
	public RecruiterDTO getRec(Long rec_id) throws Exception {
		Recruiter rec = recRepo.findById(rec_id).orElseThrow(()-> new ResourceNotFoundException("Invalid Id"));
		return mapper.map(rec,  RecruiterDTO.class);
	}

	@Override
	public RecruiterDetailsDTO getRecDetails(Long rec_id) throws Exception {
       RecruiterDetails rec = recDetRepo.findById(rec_id).orElseThrow(()-> new ResourceNotFoundException("Invalid Id"));
		
		return mapper.map(rec, RecruiterDetailsDTO.class);
	}

	@Override
	public RecruiterDetailsDTO updateRecDetails(Long rec_id, RecruiterDetailsDTO dto) throws Exception {
		RecruiterDetails rec = recDetRepo.findById(rec_id).orElseThrow(()-> new ResourceNotFoundException("Invalid Id"));
		dto.setAdr(new Address(dto.getStreet(), dto.getCity(), dto.getState(), dto.getCountry(), dto.getZipCode()));
		RecruiterDetails updatedRec = mapper.map(dto, RecruiterDetails.class);
		rec.setAdr(updatedRec.getAdr());
		rec.setCompany_size(updatedRec.getCompany_size());
		rec.setCompanyName(updatedRec.getCompanyName());
		rec.setDescription(updatedRec.getDescription());
		rec.setIndustry(updatedRec.getIndustry());
		rec.setWebsite(updatedRec.getWebsite());
		updatedRec = recDetRepo.save(rec);
		return mapper.map(updatedRec,RecruiterDetailsDTO.class);
	}

	@Override
	public RecruiterDetailsDTO authenticateRec(AuthReqDTO req) throws Exception {
		Recruiter rec = recRepo.findByEmailAndPassword(req.getEmail(),req.getPassword()).orElseThrow(()-> new ResourceNotFoundException("Invalid credentials"));
		
		RecruiterDetails recDet = recDetRepo.findById(rec.getRec_id()).orElseThrow(()-> new ResourceNotFoundException("Id not valid"));
		
		return mapper.map(recDet,RecruiterDetailsDTO.class);
	}

	@Override
	public List<VacancyDTO> getAllVacancies(Long rec_id) throws Exception {
		List<VacancyDTO> vac =  new ArrayList<>();
		List<Vacancy> vacancies = vacRepo.findAllById(rec_id);
		
		for(Vacancy v : vacancies)
		{
			VacancyDTO vdto = mapper.map(v, VacancyDTO.class);
			vac.add(vdto);
		}
		return vac;
		
	}

	@Override
	public VacancyDTO addNewVac(VacancyDTO dto) throws Exception 
	{
		dto.setRequirements(new VacancyRequirements(dto.getEducation(),dto.isCpp(),dto.isJava(),dto.isDotNet(),dto.isNodeJS(),dto.isReactJS(),dto.isSpring(),dto.isLinux(),dto.isDevopsTech(),dto.isDatabase()));
		Vacancy vac = mapper.map(dto, Vacancy.class);
		Recruiter rec = recRepo.findById(dto.getRec_id()).orElseThrow(()-> new ResourceNotFoundException("Id not valid"));
		vac.setOwner(rec);
		vacRepo.save(vac);
		return mapper.map(vac, VacancyDTO.class);
	}

	@Override
	public List<SeekerDTO> getAllSeekers(Long vac_id) throws Exception {
		Vacancy vac = vacRepo.findById(vac_id).orElseThrow(()-> new ResourceNotFoundException("Id not valid"));
		List<SeekerDTO> seeks = new ArrayList<>();
		List<Seeker> seekers = vac.getSeekers();
		for(Seeker s : seekers)
		{
			seeks.add(mapper.map(s, SeekerDTO.class));
		}
		return seeks;
		
		
	}
	
//	@Override
//	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
//		Recruiter rec = recRepo.findByEmail(email).orElseThrow(()-> new UsernameNotFoundException("Email not valid"));
//		
//		return new User(rec.getEmail(),rec.getPassword(),mapRoleToAuthority(rec.getRole()));
//	}
//	
//	private Collection<GrantedAuthority> mapRoleToAuthority(Role role)
//	{
//		SimpleGrantedAuthority sga = new SimpleGrantedAuthority(role.getName());
//		Collection<GrantedAuthority> list = new ArrayList<>();
//		list.add(sga);
//		return list;
//	}
//	
	
	

}
