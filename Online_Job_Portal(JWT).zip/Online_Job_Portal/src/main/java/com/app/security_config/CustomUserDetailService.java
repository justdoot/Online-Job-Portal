package com.app.security_config;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.app.dao.RecruiterDao;
import com.app.dao.SeekerDao;
import com.app.recruiter.entities.Recruiter;
import com.app.roles.entities.Role;
import com.app.seeker.entities.Seeker;

import lombok.NoArgsConstructor;

@NoArgsConstructor
@Service
public class CustomUserDetailService implements UserDetailsService{
	
	private SeekerDao seekerRepo;
	
	private RecruiterDao recRepo;
	
	@Autowired
	public CustomUserDetailService(SeekerDao seekerRepo, RecruiterDao recRepo)
	{
		this.seekerRepo = seekerRepo;
		this.recRepo = recRepo;
	}
	

	@Override
	public UserDetails loadUserByUsername(String email) {
		try
		{
		Seeker seeker = seekerRepo.findByEmail(email).orElseThrow(()-> new UsernameNotFoundException("Email not valid"));
		return new User(seeker.getEmail(),seeker.getPassword(),mapRoleToAuthority(seeker.getRole()));
		}
		catch(Exception e)
		{
			try
			{
				Recruiter rec = recRepo.findByEmail(email).orElseThrow(()-> new UsernameNotFoundException("Email not valid"));
				return new User(rec.getEmail(),rec.getPassword(),mapRoleToAuthority(rec.getRole()));
			}
			catch(Exception ee)
			{
				return null;
				
			}
			
		}
		
		
	}
	
	private Collection<GrantedAuthority> mapRoleToAuthority(Role role)
	{
		SimpleGrantedAuthority sga = new SimpleGrantedAuthority(role.getName());
		Collection<GrantedAuthority> list = new ArrayList<>();
		list.add(sga);
		return list;
	}

}
