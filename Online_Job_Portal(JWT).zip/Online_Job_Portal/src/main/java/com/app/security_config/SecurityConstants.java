package com.app.security_config;

public class SecurityConstants {
	public static final String JWT_SECRET="secret";
	public static final int JWT_EXPIRATION = 7000;
}
